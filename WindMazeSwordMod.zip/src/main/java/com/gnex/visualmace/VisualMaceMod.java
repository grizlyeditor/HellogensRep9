package com.gnex.visualmace;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = VisualMaceMod.MODID, name = VisualMaceMod.NAME, version = VisualMaceMod.VERSION)
public class VisualMaceMod {
    public static final String MODID = "visualmace";
    public static final String NAME = "Visual Mace Mod";
    public static final String VERSION = "1.0";

    @SidedProxy(clientSide = "com.gnex.visualmace.ClientProxy", serverSide = "com.gnex.visualmace.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ModItems.init();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.registerRenderers();
    }
}