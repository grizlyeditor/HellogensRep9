package com.gnex.visualmace;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModItems {
    public static Item visualMace;

    public static void init() {
        visualMace = new VisualMace();
        GameRegistry.register(visualMace);
    }
}