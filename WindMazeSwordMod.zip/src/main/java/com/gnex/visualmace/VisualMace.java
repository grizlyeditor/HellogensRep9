package com.gnex.visualmace;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class VisualMace extends ItemSword {
    public VisualMace() {
        super(ToolMaterial.DIAMOND);
        setUnlocalizedName("visualmace");
        setRegistryName("visualmace");
        setCreativeTab(CreativeTabs.COMBAT);
    }

    @SubscribeEvent
    public void onHit(LivingHurtEvent event) {
        if (event.getSource().getTrueSource() instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) event.getSource().getTrueSource();
            if (player.getHeldItemMainhand().getItem() instanceof VisualMace) {
                double fallHeight = player.fallDistance;
                float damage = Math.min((float) fallHeight * 10F, 100F);
                event.setAmount(damage);

                if (player.fallDistance > 0.0F && !player.onGround) {
                    event.getEntityLiving().motionY += 1.2D;
                }

                if (player.motionY < -0.2D) {
                    event.getEntityLiving().motionY += 2.0D;
                    event.getEntityLiving().fallDistance = 0.0F;
                }
            }
        }
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        if (!world.isRemote) {
            player.motionY += 1.5D;
            player.motionX += (-Math.sin(Math.toRadians(player.rotationYaw))) * 2.0D;
            player.motionZ += (Math.cos(Math.toRadians(player.rotationYaw))) * 2.0D;
            player.fallDistance = 0.0F;
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, player.getHeldItem(hand));
    }
}