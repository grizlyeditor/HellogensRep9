package com.gnex.visualmace;

import net.minecraftforge.client.model.ModelLoader;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends CommonProxy {
    @Override
    public void registerRenderers() {
        ModelLoader.setCustomModelResourceLocation(ModItems.visualMace, 0,
                new ModelResourceLocation("visualmace:visualmace", "inventory"));
    }
}
