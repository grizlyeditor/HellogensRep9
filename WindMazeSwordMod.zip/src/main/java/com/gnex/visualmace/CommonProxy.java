package com.gnex.visualmace;

public class CommonProxy {
    public void registerRenderers() {
        // Server-side does nothing
    }
}