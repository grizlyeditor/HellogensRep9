package com.gnex.windmazesword;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraft.item.Item;

@Mod(modid = WindMazeSwordMod.MODID, name = "Wind Maze Sword Mod", version = "1.0")
public class WindMazeSwordMod {
    public static final String MODID = "windmazesword";

    public static Item windMazeSword;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        windMazeSword = new ItemWindMazeSword();
        GameRegistry.register(windMazeSword.setRegistryName("wind_maze_sword"));
    }
}