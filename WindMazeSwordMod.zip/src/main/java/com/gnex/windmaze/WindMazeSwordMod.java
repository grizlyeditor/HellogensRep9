package com.gnex.windmazesword;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;

public class ItemWindMazeSword extends ItemSword {

    public ItemWindMazeSword() {
        super(ToolMaterial.DIAMOND);
        setUnlocalizedName("wind_maze_sword");
        setRegistryName("wind_maze_sword");
        setMaxStackSize(1);
    }

    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        if (attacker instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) attacker;
            double fall = player.fallDistance;
            if (fall > 0) {
                float damage = Math.min((float)(fall * 5), 1000);
                target.attackEntityFrom(DamageSource.causePlayerDamage(player), damage);
                target.motionY = 3.8D;
                player.fallDistance = 0;
                World world = player.world;
                for (int i = 0; i < 15; i++) {
                    world.spawnParticle(EnumParticleTypes.TOTEM, 
                        target.posX + Math.random() - 0.5, 
                        target.posY + 1, 
                        target.posZ + Math.random() - 0.5, 
                        0, 0.1, 0);
                }
                world.playSound(null, player.posX, player.posY, player.posZ, 
                    SoundEvents.ENTITY_ENDERDRAGON_FLAP, SoundCategory.PLAYERS, 1.0f, 1.0f);
            }
        }
        return super.hitEntity(stack, target, attacker);
    }

    @Override
    public void onUpdate(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (entity instanceof EntityPlayer && selected) {
            ((EntityPlayer) entity).fallDistance = 0;
        }
        super.onUpdate(stack, world, entity, slot, selected);
    }
}